var mascotList = [ "ruri1.png", "ruri2.png", "ruri3.png" ];
